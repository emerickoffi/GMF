declare interface ISnapShotsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  ListName: string;
  ListNameFieldLabel:string;
  language:string;
  ViewAll:string;
  ViewAllFieldLabel:string;
}

declare module 'SnapShotsWebPartStrings' {
  const strings: ISnapShotsWebPartStrings;
  export = strings;
}
