import { ISnapShotsProps } from '../ISnapShotsProps';
import { DisplayMode } from '@microsoft/sp-core-library';
import { ISnapShotsState } from '../ISnapShotsState';


export interface IDetailedProps extends ISnapShotsProps {
  imageURLs: any;
  itemid: any;
}

export interface IDetailedState extends ISnapShotsState{
  
}