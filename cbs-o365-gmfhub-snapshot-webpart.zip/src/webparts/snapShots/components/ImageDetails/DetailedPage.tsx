import * as React from 'react';
import SnapShots from '../SnapShots';
import { ISnapShotsProps } from '../ISnapShotsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ISnapShotsState } from '../ISnapShotsState';
import { ServiceScope } from '@microsoft/sp-core-library';
import { ImageService } from '../../../../services/ImageService';
import { IDataService } from '../../../../services/IDataService';
import { Image, IImageProps, ImageFit } from 'office-ui-fabric-react/lib/Image';
import { IDetailedProps } from './IDetailedProps';
import {IDetailedState} from './IDetailedState';
export default class DetailedPage extends React.Component<IDetailedProps> {
    private dataCenterServiceInstance: IDataService;
    public images: any;
    
    public constructor(props: IDetailedProps, state: IDetailedState) {
        super(props);
        
        this.images=props.imageURLs.filter(list=>list.Id==this.props.itemid);
    }
    
  public imageProps: IImageProps = {
    src: 'http://placehold.it/800x300',
    imageFit: ImageFit.center,
    width: '100%',
    height: '100%',
    onLoad: ev => console.log('image loaded', ev)
  };
    public render(): JSX.Element {
        return (
            <div>
                <div>
                    
                  { this.props.dropDownLanguage=="EN" && this.images.map((imageList, key) => {
                    return (<div > 
                            <img {...(this.imageProps as any)} src={imageList.FileRef} width="100%" height="100%" />
                            <span>{imageList.Desc} - <a href={imageList.Link.Url} target="_blank">{imageList.Link.Description}</a></span>
                            </div>);
            }) }
                  { this.props.dropDownLanguage=="ES" && this.images.map((imageList, key) => {
                    return (<div > 
                            <img {...(this.imageProps as any)} src={imageList.FileRef} width="100%" height="100%" />
                            <span>{imageList.DescES} - <a href={imageList.LinkES.Url} target="_blank">{imageList.LinkES.Description}</a></span>
                            </div>);
            }) }
                  { this.props.dropDownLanguage=="PT" && this.images.map((imageList, key) => {
                    return (<div > 
                            <img {...(this.imageProps as any)} src={imageList.FileRef} width="100%" height="100%" />
                            <span>{imageList.DescPT} - <a href={imageList.LinkPT.Url} target="_blank">{imageList.LinkPT.Description}</a></span>
                            </div>);
            }) }   
                </div>
            </div>
        );
    }
    
}