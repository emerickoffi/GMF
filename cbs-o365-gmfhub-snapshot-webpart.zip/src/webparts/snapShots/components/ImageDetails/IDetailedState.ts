import { ISnapShotsState } from '../ISnapShotsState';




export interface IDetailedState extends ISnapShotsState{
  
}