import { ISnapShotsProps } from '../ISnapShotsProps';
import { DisplayMode } from '@microsoft/sp-core-library';
import { ISnapShotsState } from '../ISnapShotsState';


export interface IUploadImageProps extends ISnapShotsProps {
  imageURLs: any;
  itemid: any;
}

