import * as React from 'react';
import { DefaultButton, PrimaryButton} from 'office-ui-fabric-react';
import SnapShots from '../SnapShots';
import { ISnapShotsProps } from '../ISnapShotsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { IUploadImageState } from '../UploadImage/IUploadImageState';
import { ServiceScope } from '@microsoft/sp-core-library';
import { ImageService } from '../../../../services/ImageService';
import { IDataService } from '../../../../services/IDataService';
import { Image, IImageProps, ImageFit } from 'office-ui-fabric-react/lib/Image';
import { IUploadImageProps } from './IUploadImageProps';
import { Checkbox,  ICheckboxStyles} from 'office-ui-fabric-react/lib/Checkbox';  

import { Dropdown, DropdownMenuItemType, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
const options: IDropdownOption[] = [
    { key: 'Select Lanaguage', text: 'Select Lanaguage', itemType: DropdownMenuItemType.Header },
    { key: 'EN', text: 'English' },
    { key: 'ES', text: 'Spanish' },
    { key: 'PT', text: 'Portuguese' },
  
  ];
  const uploadStyle={ color:'#005dab','font-size':'18px','font-weight': 'bold',};
const textBoxStyle = {
    color: 'blue',
    border: '1px solid rgb(109, 104, 104)',
    padding: '5px',
    'border-radius': '4px',
    width: '99%',
    height:'2em',
  };
  
   
export default class UploadImagePage extends React.Component<IUploadImageProps, IUploadImageState> {
    private dataCenterServiceInstance: IDataService;
    public images: any;
    public message:any;
    public isESChecked: any;
    public languages:any;
    public constructor(props: IUploadImageProps, state: IUploadImageState) {
        super(props);
        
        this.isESChecked=false;
        this.dropdownChange = this.dropdownChange.bind(this);
        this._onCheckboxChange=this._onCheckboxChange.bind(this);
        this._onCheckboxChangeES=this._onCheckboxChangeES.bind(this);
        this._onCheckboxChangePT=this._onCheckboxChangePT.bind(this);
        let serviceScope: ServiceScope = this.props.serviceScope;
        this.dataCenterServiceInstance = serviceScope.consume(ImageService.serviceKey);
        this.setState({
          selectedLanguage: []}
        );
    }
    public _onCheckboxChange(ev: React.FormEvent<HTMLElement>, isChecked: boolean) { 
      console.log(`The option has been changed to ${isChecked}.`); 
      if(isChecked)
      {
        if(this.state!=null)
        {
          this.setState(prevState => ({
            selectedLanguage: [...prevState.selectedLanguage, 'EN']
          }));
        }
        else{
          this.setState({
            selectedLanguage: ['EN']}
          );
        }
      }
      else{
        if(this.state!=null)
        {
          var array = [...this.state.selectedLanguage]; // make a separate copy of the array
          var index = array.indexOf('EN');
          if (index !== -1) {
            array.splice(index, 1);
            this.setState({selectedLanguage: array});
          }
        }
      }
    }
    public _onCheckboxChangeES(ev: React.FormEvent<HTMLElement>, isChecked: boolean) { 
      
      if(isChecked)
      {
        if(this.state!=null)
        {
          this.setState(prevState => ({
            selectedLanguage: [...prevState.selectedLanguage, 'ES']
          }));
        }
        else{
          this.setState({
            selectedLanguage: ['ES']}
          );
        }
      }
      else{
      if(this.state!=null)
      {
        var array = [...this.state.selectedLanguage]; // make a separate copy of the array
        var index = array.indexOf('ES');
        if (index !== -1) {
          array.splice(index, 1);
          this.setState({selectedLanguage: array});
        }
      }
    }
  }
    public _onCheckboxChangePT(ev: React.FormEvent<HTMLElement>, isChecked: boolean) { 
      if(isChecked)
      {
        if(this.state!=null)
        {
          this.setState(prevState => ({
            selectedLanguage: [...prevState.selectedLanguage, 'PT']
          }));
        }
        else{
          this.setState({
            selectedLanguage: ['PT']}
          );
        }
      }
      else{
      if(this.state!=null)
      {
        var array = [...this.state.selectedLanguage]; // make a separate copy of the array
        var index = array.indexOf('PT');
        if (index !== -1) {
          array.splice(index, 1);
          this.setState({selectedLanguage: array});
        }
      }
    }
  } 
    private _onChangeES(event) {
      console.log(`The PT option has been changed to ${event}`);
    }  
  private uploadFileFromControl() {

    let myfile = (document.querySelector("#newfile") as HTMLInputElement).files[0];
    let desc, descES, descPT,link,linkPT,linkES;
    desc= descES= descPT=link=linkPT=linkES = "";
    if(document.querySelector("#Desc")!=null)
    {
      desc = (document.querySelector("#Desc") as HTMLInputElement).value;
    }
    if(document.querySelector("#DescES")!=null)
    {
      descES = (document.querySelector("#DescES") as HTMLInputElement).value;
    }
    if(document.querySelector("#DescPT")!=null)
    {
      descPT = (document.querySelector("#DescPT") as HTMLInputElement).value;
    }

    let language = this.state.selectedLanguage;
    if (myfile != undefined && this.state!=null && this.state.selectedLanguage.length>0 &&(desc!=''||descES!=''||descPT!='')) {
      try {
        this.toggelDisable();
        this.dataCenterServiceInstance.GetFolderServerRelativeURL(myfile, myfile.name, this.props.ListName, desc,descES,descPT, language).then((fileURL) => {
          console.log(fileURL);
          let response: string = fileURL;
          if (response.indexOf("true")>-1) {
            //alert("Image uploaded successfully");
            this.message="Image uploaded successfully. Please click on close to go back.";
            this.toggelDisable();
            this.setState(() => {
              return {
                ...this.state,
                showUpload: false,
                itemid: '0'
              };
            });
            //this._closeDialog_upload();
          }
          else {
            this.message="Image not upload or updated the description. Could you please try after some time.";
            this.toggelDisable();
          }
          //this.AppendToRichTextEditor(fileURL, files.fileList[0].name, fileExtension, fileDivId, rteEvent);    
        }).catch((error) => {
          alert("Error while processing the promise call " + error);
          this.toggelDisable();
        });
      } catch (error) {
        console.log("Error in HandleFiles " + error);
        this.toggelDisable();
      }
    }
    else {
      this.message="Please upload file , select any one language and description ";
      this.toggelDisable();
    }
   
  }
  
    private dropdownChange(event) {
      console.log(event);
      this.setState(() => {
        return {
          ...this.state,
          selectedLanguage: event.key,
  
        };
      });
    }
    private _closeDialog_upload = (): void => {
      this.setState({ hideDialog_upload: true });
    }
    private toggelDisable() {
      
      this.setState(() => {
        return {
          ...this.state,
          disableupload: !this.state.disableupload,
        };
      });
    }    
    public render(): JSX.Element {
        return (
         
        <div style={{maxWidth:'100%'}}>

        <div style={uploadStyle}><span>Upload Image</span></div>
        <div className="ms-Grid-row gridRow" style={{margin:'0px'}}>
        <hr style={{border:'1px solid',color:'#005dab'}}/>
</div>

        <input type="file" name="myFile" id="newfile"></input>
        <br></br>
        <br />
        <div id="ddlLanguage" className="ddlStyles" >
        <span>Select Language: </span>
        <Checkbox label="English (EN)" onChange={ this._onCheckboxChange }  />

        <Checkbox label="Spanish (ES)" onChange={ this._onCheckboxChangeES }   />

        <Checkbox label="Portuguese (PT)"  onChange={ this._onCheckboxChangePT } />
    
        </div>
        <br />
        {this.state != null && [...this.state.selectedLanguage].indexOf('EN')>-1  && <div>
          Description: <input type="text" name="Desc"  id="Desc" style={textBoxStyle} placeholder="Description"></input>
        <br />
          </div>}

          {this.state != null && [...this.state.selectedLanguage].indexOf('ES')>-1  && <div>
        
          Descripción: <input type="text" name="DescES"  id="DescES" style={textBoxStyle} placeholder="Descripción"></input>
        </div>}

        {this.state != null && [...this.state.selectedLanguage].indexOf('PT')>-1  && <div>
        
        Descrição: <input type="text" name="DescPT"  id="DescPT" style={textBoxStyle} placeholder="Descrição"></input>
        <br />
        </div>}
        <p>
          </p>
      
      <div><PrimaryButton text="Upload" onClick={() => this.uploadFileFromControl()}  disabled={(this.state!=null &&this.state.selectedLanguage.length>0)?false:true}/>
            {/* <DefaultButton text="Cancel" onClick={() => this._closeDialog_upload()} /> */}
 </div>
        <div><span>{this.message}</span></div>
    </div>
        );
    }
}