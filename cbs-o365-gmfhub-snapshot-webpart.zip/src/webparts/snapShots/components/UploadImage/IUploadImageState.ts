import { ISnapShotsState } from '../ISnapShotsState';

export interface IUploadImageState extends ISnapShotsState {
    disableupload:boolean;
    isChecked: boolean;
}
