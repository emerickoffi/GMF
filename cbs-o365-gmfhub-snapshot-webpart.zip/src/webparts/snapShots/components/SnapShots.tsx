import * as React from 'react';
import styles from './SnapShots.module.scss';
import { ISnapShotsProps } from './ISnapShotsProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { ISnapShotsState } from './ISnapShotsState';
import { ServiceScope } from '@microsoft/sp-core-library';
import { ImageService } from '../../../services/ImageService';
import { IDataService } from '../../../services/IDataService';
import { Image, IImageProps, ImageFit } from 'office-ui-fabric-react/lib/Image';
import ImageDetails from './ImageDetails/DetailedPage';
import { DefaultButton, PrimaryButton} from 'office-ui-fabric-react';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { Dropdown, DropdownMenuItemType, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import { ContextualMenu } from 'office-ui-fabric-react/lib/ContextualMenu';
import { SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions } from '@microsoft/sp-http';
import pnp from "sp-pnp-js";
import { hiddenContentStyle, mergeStyles, ScreenWidthMaxMedium } from 'office-ui-fabric-react/lib/Styling';
import ReactFileReader from 'react-file-reader';
import { initializeIcons } from '@uifabric/icons';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import { Link } from 'office-ui-fabric-react/lib/Link';
import UploadImage  from './UploadImage/UploadImagePage';
const options: IDropdownOption[] = [
  { key: 'Select Lanaguage', text: 'Select Lanaguage', itemType: DropdownMenuItemType.Header },
  { key: 'English', text: 'English' },
  { key: 'Spanish', text: 'Spanish' },
  { key: 'Portuguese', text: 'Portuguese' },

];
const screenReaderOnly = mergeStyles(hiddenContentStyle);
export interface IButtonExampleProps {
  // These are set based on the toggles shown above the examples (not needed in real code)
  disabled?: boolean;
  checked?: boolean;
}
const ViewAllstyle={
  'color': 'white',
    
  'display': 'block',
  'font-size': '16px',
  'margin-block-start': '1em',
  'margin-block-end': '1em',
  'margin-inline-start': '0px',
  'margin-inline-end': '0px',
  'margin-bottom': '12px',
  'margin-top': '12px',
  'text-align':'right',
};
const uploadstyle = {
    'color': 'white',
    'text-align':'center',
    'display': 'block',
    'font-size': '16px',
    'margin-block-start': '1em',
    'margin-block-end': '1em',
    'margin-inline-start': '0px',
    'margin-inline-end': '0px',
    'margin-bottom': '12px',
    'margin-top': '12px',
};
const linkStyle={
  'color':'#005dab',
};
const dropdDown = {
  width: '30px',
};
const headingStyle={
  'color': '#005dab',
    
  'display': 'block',
  'font-size': '18px',
  'margin-block-start': '1em',
  'margin-block-end': '1em',
  'margin-inline-start': '0px',
  'margin-inline-end': '0px',
  'font-weight': 'bold',
  'margin-bottom': '10px',
  'margin-top': '12px',
};


const divStyle = {
  color: 'blue',
  border: '1px solid #ddd',
  padding: '5px',
  'border-radius': '4px',
  'object-fit': 'cover',
    'object-position': 'center center',
};
const webpartStyle={
//border:'1px solid',
};
const imageGridRow={
  margin:'0px',
};
const ddlStyles = {
  width: '400px !important',
};
const gridRow = {
  
  'padding': '0px',
    'background-color': '#fff',
    'color': 'white',
    'font': 'caption',
    'margin':'0px',
};
function changeBackground(e) {
  e.target.style.background = 'red';
}



export default class SnapShots extends React.Component<ISnapShotsProps, ISnapShotsState> {
  private dataCenterServiceInstance: IDataService;
  private itemid: any;
  public disable: boolean;
  
  public language: any;
  public constructor(props: ISnapShotsProps, state: ISnapShotsState) {
    super(props);
    this.disable = false;
    this.state = {
      imageURLs: [],
      showDetails: false,
      itemid: '0',
      listName: this.props.ListName,
      showUpload: false,
      uploadButtonDisable: false,
      dropDownLanguage: this.props.dropDownLanguage,
      selectedLanguage: [],
      hideDialog: true,
      isDraggable: false,
      hideDialog_upload:true,
      isENChecked:false,
      isESChecked:false,
      isPTChecked:false,
    };
    this.dropdownChange = this.dropdownChange.bind(this);
    let serviceScope: ServiceScope = this.props.serviceScope;
    this.dataCenterServiceInstance = serviceScope.consume(ImageService.serviceKey);

    this.dataCenterServiceInstance.getImages(this.props.ListName, this.props.dropDownLanguage).then((carouselItems: any) => {
      this.setState({
        imageURLs: carouselItems,
        listName: this.props.ListName,
        dropDownLanguage: this.props.dropDownLanguage
      });
    });
  }
  private _labelId: string = "SampleLable";//getId('dialogLabel');
  private _subTextId: string = "Sample sub text";//getId('subTextLabel');
  private _dragOptions = {
    moveMenuItemText: 'Move',
    closeMenuItemText: 'Close',
    menu: ContextualMenu,
  };
  public Base64ToArrayBuffer(base64) {
    try {
      var binary_string = window.atob(base64.split(',')[1]);
      var len = binary_string.length;
      var bytes = new Uint8Array(len);
      for (var i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
      }
      return bytes.buffer;
    } catch (error) {
      console.log("Error in Base64ToArrayBuffer " + error);
    }
  }
  private getStyles() {
    return {
        main: [{
            selectors: {
                [""]: { // Apply at root 
                    minWidth: '450px'
                }
            }
        }]
    };
}
  public imageProps: IImageProps = {
    src: 'http://placehold.it/800x300',
    imageFit: ImageFit.center,
    width: '100%',
    height: 180,
    className: 'ImgStyles',
    onLoad: ev => console.log('image loaded', ev)
  };
  public imageClick = (key) => {
    console.log('Click!!!!' + key);
    this.ShowImageDetails(key);
  }
  //to show all images once image is uploaded or click on back button in the image details component
  private ShowImageDetails(itemid: any): void {
    this.itemid = itemid;
    //this.props.itemid=itemid;
    this.setState({itemid: itemid});
    // this.setState(() => {
    //   return {
    //     ...this.state,
    //     showDetails: true,
    //     itemid: itemid
    //   };

    // });
    this._showDialog();
  }
  //to Show upload component on add a pic click
  private showUpload(): void {
    this.setState(() => {
      return {
        ...this.state,
        itemid: '0',
        
        hideDialog_upload:true,
      };
    });
    this._showDialog_upload();
  }
  //Cancel button event in upload image component
  private Cancel() {
    this.setState(() => {
      return {
        ...this.state,
        showUpload: false,
        itemid: '0'
      };
    });
  }
  private uploadFileFromControl() {

    let myfile = (document.querySelector("#newfile") as HTMLInputElement).files[0];
    let desc = (document.querySelector("#Desc") as HTMLInputElement).value;
    let language = this.state.selectedLanguage;
    if (myfile != undefined && desc != "") {
      try {
        this.toggelDisable();
        this.dataCenterServiceInstance.GetFolderServerRelativeURL(myfile, myfile.name, this.props.ListName, desc, language).then((fileURL) => {
          console.log(fileURL);
          let response: string = fileURL;
          if (response.indexOf("true")) {
            alert("Image uploaded successfully");
            this.toggelDisable();
            this.setState(() => {
              return {
                ...this.state,
                showUpload: false,
                itemid: '0'
              };
            });
            this._closeDialog_upload();
          }
          else {
            alert("Image not upload or updated the description. Could you please try after some time.");
            this.toggelDisable();
          }
          //this.AppendToRichTextEditor(fileURL, files.fileList[0].name, fileExtension, fileDivId, rteEvent);    
        }).catch((error) => {
          alert("Error while processing the promise call " + error);
          this.toggelDisable();
        });
      } catch (error) {
        console.log("Error in HandleFiles " + error);
        this.toggelDisable();
      }
    }
    else {
      alert("Please enter desc and language");
    }
    // if (myfile.size <= 10485760) {
    //   pnp.sp.site.rootWeb.getFolderByServerRelativeUrl(`SampleImages`).files.add(myfile.name, myfile, true).then(f => {
    //     console.log("File Uploaded !!!");
    //     f.file.getItem().then(item => {
    //       item.update({
    //         Desc: desc
    //       }).then((myupdate) => {
    //         console.log(myupdate);
    //         console.log("Metadata Updated");
    //         alert("Image uploaded successfully!");
    //         this.setState(() => {
    //           return {
    //             ...this.state,
    //             showUpload: false,
    //             itemid: '0'
    //           };
    //         });
    //       });
    //     });
    //   });
    //}
    //Get the file from File DOM

  }
  private ShowAllImageDetails(): void {
    this.setState(() => {
      return {
        ...this.state,
        showDetails: false,
        itemid: '0'
      };
    });
  }
//dropdown change event
  private dropdownChange(event) {
    console.log(event);
    this.setState(() => {
      return {
        ...this.state,
        selectedLanguage: event.key,

      };
    });
  }

  private _showDialog = (): void => {
    
    this.setState({
        hideDialog: false,

    
  });
  }
  
  private _showDialog_upload = (): void => {
    
    this.setState({
        hideDialog_upload: false,

    
  });
  }
  private _closeDialog = (): void => {
    this.setState({ hideDialog: true });
  }
  private _closeDialog_upload = (): void => {
    this.setState({ hideDialog_upload: true });
  }

  private _toggleDraggable = (): void => {
    this.setState({ isDraggable: !this.state.isDraggable });
  }
  
  private toggelDisable() {

    this.setState(() => {
      return {
        ...this.state,
        uploadButtonDisable: !this.state.uploadButtonDisable,

      };
    });
  }


  public render(): React.ReactElement<ISnapShotsProps> {
    const { hideDialog, isDraggable, hideDialog_upload } = this.state;
    return (<div style={webpartStyle}> 
      {/** to display web part title from webpart panel */}
      <div className="ms-Grid-row" style={gridRow}>
        <div className={`ms-Grid-col ms-sm3 ms-md4 ms-lg4 `} >
          <div><span style={headingStyle}>{this.props.description}</span></div>
        </div>
        
        {/* to display add a pic link*/}
        <div className={`ms-Grid-col ms-sm2 ms-md4 ms-lg4 `}>
          {this.state.showUpload == false && this.state.showDetails == false &&
            <div style={uploadstyle}>
              <Link onClick={() => this.showUpload()} style={linkStyle}>
                + Add a pic</Link>
            </div>
          }
        </div>
        {/* to display view all link*/}
        <div className={`ms-Grid-col ms-sm2 ms-md4 ms-lg4 `}>
          {this.state.showUpload == false && this.state.showDetails == false &&
            <div style={ViewAllstyle}>
              <Link href={this.props.viewAll} style={linkStyle}>
                View all</Link>
            </div>
          }
        </div>
      </div>
      {/* to display all images if imagesURLs array length greater than zero */}
      <div className="ms-Grid-row gridRow" style={imageGridRow}>
        <hr style={{border:'1px solid',color:'#005dab'}}/>
</div>
      <div className="ms-Grid-row gridRow" style={imageGridRow}>

        {this.state.showDetails == false && this.state.dropDownLanguage=="EN" && this.state.showUpload == false && this.state.imageURLs.length > 0 && this.state.imageURLs.map((imageList, key) => {
          return (<div className={`ms-Grid-col ms-sm3 ms-md4 ms-lg3 `}>
            

            <img {...(this.imageProps as any)} src={imageList.FileRef} onClick={() => this.imageClick(imageList.Id)} className={styles.ImgStyles} style={divStyle} />
            <br /> <span>{imageList.Desc}</span>
          </div>

          );

        })}

{this.state.showDetails == false && this.state.dropDownLanguage=="ES" && this.state.showUpload == false && this.state.imageURLs.length > 0 && this.state.imageURLs.map((imageList, key) => {
          return (<div className={`ms-Grid-col ms-sm3 ms-md4 ms-lg3 `}>
             <img {...(this.imageProps as any)} src={imageList.FileRef} onClick={() => this.imageClick(imageList.Id)} className={styles.ImgStyles} style={divStyle} />
              <br /> <span>{imageList.DescES}</span>
          </div>
        );
      })}

{this.state.showDetails == false && this.state.dropDownLanguage=="PT" && this.state.showUpload == false && this.state.imageURLs.length > 0 && this.state.imageURLs.map((imageList, key) => {
          return (<div className={`ms-Grid-col ms-sm3 ms-md4 ms-lg3 `}>
             <img {...(this.imageProps as any)} src={imageList.FileRef} onClick={() => this.imageClick(imageList.Id)} className={styles.ImgStyles} style={divStyle} />
              <br /> <span>{imageList.DescPT}</span>
          </div>
        );
      })}

      </div>
{/* to show no images */}
      {this.state.showDetails == false && this.state.showUpload == false && this.state.imageURLs.length == 0 && <div><span>no images</span></div>}

{/* start of to display one image details */}
<Dialog
          hidden={hideDialog}
          onDismiss={this._closeDialog}
          dialogContentProps={{
            type: DialogType.close,
            closeButtonAriaLabel: 'Close',
            }}
          modalProps={{
            titleAriaId: this._labelId,
            subtitleAriaId: this._subTextId,
            isBlocking: true,
            isDarkOverlay:true,
          }}
        >
      

        <div>
        <ImageDetails  itemid={this.state.itemid} imageURLs={this.state.imageURLs} {...this.props} />
        </div>
      
          <DialogFooter>
            <PrimaryButton onClick={this._closeDialog} text="Close" />
            
          </DialogFooter>
        </Dialog>
{/*  end of to display one image details */}
{/** */}
<Dialog
          hidden={hideDialog_upload}
          onDismiss={this._closeDialog_upload}
          dialogContentProps={{
            type: DialogType.close,
            closeButtonAriaLabel: 'Close',
            }}
          modalProps={{
            titleAriaId: this._labelId,
            subtitleAriaId: this._subTextId,
            isBlocking: true,
            isDarkOverlay:true,
          }}
        >
{/*       
        <div style={{maxWidth:'100%'}}>

          <h2>Upload Image</h2>
          <hr></hr>

          <input type="file" name="myFile" id="newfile"></input>
          <br></br>
          <br />
          <div id="ddlLanguage" className="ddlStyles" >
          
          <Dropdown

            placeholder="Select an option"
            label="Language"
            options={options}
            required={true}
            id="dropDownLanguage"
            onChanged={this.dropdownChange}
            defaultValue="Select Lanaguage"
            
          />
          </div>
          <br />
          Description/descripción/descrição: <br/><input type="text" name="Desc" id="Desc" style={textBoxStyle}></input>
          <p>
            </p>
        </div>
      */}
      <UploadImage {...this.state} {...this.props}></UploadImage>
<DialogFooter>
         
</DialogFooter>
        </Dialog>

    </div>);
  }
}
