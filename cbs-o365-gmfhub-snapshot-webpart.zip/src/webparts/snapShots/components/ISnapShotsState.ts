export interface ISnapShotsState {
    imageURLs: any;
    itemid: string;
    showDetails: boolean;
    listName: string;
    showUpload:boolean;
    uploadButtonDisable:boolean;
    dropDownLanguage:string;
    selectedLanguage:string[];
    hideDialog: boolean;
    isDraggable: boolean;
    hideDialog_upload:boolean;
    isENChecked:boolean;
    isESChecked:boolean;
    isPTChecked:boolean;
}
