import { ServiceScope } from '@microsoft/sp-core-library';
export interface ISnapShotsProps {
  description: string;
  serviceScope: ServiceScope;
  ListName: string;
  viewAll:string;
  siteUrl:string;
  dropDownLanguage:string;
}
