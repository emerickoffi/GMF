import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
  PropertyPaneDropdown //Dropdown
} from '@microsoft/sp-webpart-base';

import * as strings from 'SnapShotsWebPartStrings';
import SnapShots from './components/SnapShots';
import { ISnapShotsProps } from './components/ISnapShotsProps';

export interface ISnapShotsWebPartProps {
  description: string;
  ListName: string;
  dropDownLanguage: string;
  ViewAll:string;
}

export default class SnapShotsWebPart extends BaseClientSideWebPart<ISnapShotsWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISnapShotsProps > = React.createElement(
      SnapShots,
      {
        description: this.properties.description,
        serviceScope: this.context.serviceScope,
        ListName: this.properties.ListName,
        viewAll: this.properties.ViewAll,//this.context.pageContext.web.absoluteUrl+'/'+this.properties.ListName,
        siteUrl: this.context.pageContext.web.absoluteUrl,
        dropDownLanguage:this.properties.dropDownLanguage,
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                }),
                PropertyPaneTextField('ListName', {
                  label: strings.ListNameFieldLabel
                }),
                PropertyPaneDropdown('dropDownLanguage', {
                  label:'Select Language',
                  options: [
                    { key: 'EN', text: 'English' },
                    { key: 'ES', text: 'Spanish' },
                    { key: 'PT', text: 'Portuguese' }
                  ]
                }),
                PropertyPaneTextField('ViewAll', {
                  label: strings.ViewAllFieldLabel
                }),
              ]
            }
          ]
        }
      ]
    };
  }
}
