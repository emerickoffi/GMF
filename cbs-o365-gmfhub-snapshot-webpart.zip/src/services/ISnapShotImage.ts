export interface ISnapShotImage {
    FileRef: string;
    Id: string;
    Desc:string;
    Link:string;
    LinkES:string;
    DescES:string;
    LinkPT:string;
    DescPT:string;
}
export interface ISPList {
    Title: string;
    Conros_ProductCode : string;
    Conros_ProductDescription :string;
  }
  export interface ISnapShotImages {
    value: ISnapShotImage[];
  }