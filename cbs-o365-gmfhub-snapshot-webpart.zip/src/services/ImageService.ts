import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IDataService } from './IDataService';
import { SPHttpClient, SPHttpClientResponse,ISPHttpClientOptions } from '@microsoft/sp-http';
import { PageContext } from '@microsoft/sp-page-context';
import { ISnapShotImage, ISnapShotImages } from './ISnapShotImage';

export class ImageService implements IDataService {
    public static readonly serviceKey: ServiceKey<IDataService> = ServiceKey.create<IDataService>('carousel:data-service', ImageService);
    private _spHttpClient: SPHttpClient;
    private _pageContext: PageContext;
    private _currentWebUrl: string;
    private _imageserverRelativeURL: string;


    constructor(serviceScope: ServiceScope) {
        serviceScope.whenFinished(() => {
            // Configure the required dependencies  
            this._spHttpClient = serviceScope.consume(SPHttpClient.serviceKey);
            this._pageContext = serviceScope.consume(PageContext.serviceKey);
            this._currentWebUrl = this._pageContext.web.absoluteUrl;
            this._imageserverRelativeURL = this._pageContext.web.serverRelativeUrl;
        });
    }

    public GetFolderServerRelativeURL(file, FinalName, DocumentLibPath,desc,descES,descPT,language): Promise<any> {      
        try {      
            return new Promise((resolve) => {      
                    const spOpts: ISPHttpClientOptions = {      
                        body: file      
                    };      
                    var redirectionURL = this._pageContext.web.absoluteUrl+ "/_api/Web/GetFolderByServerRelativeUrl('"+DocumentLibPath+"')/Files/Add(url='" + FinalName + "', overwrite=true)?$expand=ListItemAllFields";      
                    this._spHttpClient.post(redirectionURL, SPHttpClient.configurations.v1, spOpts).then((response: SPHttpClientResponse) => {        
                        response.json().then(async (responseJSON: any) => {        
                          var serverRelURL = await responseJSON.ServerRelativeUrl;      
                          //resolve(serverRelURL);
                          console.log(responseJSON.ListItemAllFields.ID);   
                          var updateDesc = this._pageContext.web.absoluteUrl +"/_api/web/lists/GetByTitle('"+DocumentLibPath+"')/items("+responseJSON.ListItemAllFields.ID+")";
                          var payload = JSON.stringify({
                            "__metadata": {
                                "type": "SP.Data."+DocumentLibPath+"Item"
                              },
                              "Desc": desc,
                              "DescES":descES,
                              "DescPT":descPT,
                              "Language": { 'results': language},
                              
                          }); 
                          var option = {
                            headers: {
                              'IF-MATCH': '*',
                              'Content-type': 'application/json;odata=verbose',
                              "accept": "application/json;odata=verbose",
                              "odata-version":"3.0",
                              'X-HTTP-Method': 'PATCH'
                            },
                            body: payload
                          };
                        
                          this._spHttpClient.post(updateDesc, SPHttpClient.configurations.v1, option).then((response: SPHttpClientResponse) => {
                                  
                                resolve(response.status + ':' + response.ok);
                            //alert(response.status + ':' + response.ok);
                        
                          });
                              
                        });        
                      });    
            });      
        } catch (error) {      
            console.log("Error in GetFolderServerRelativeURL " + error);      
        }      
    }
      
    public getImages(listName?: string, language?: string): Promise<ISnapShotImages[]> {
        var images: ISnapShotImage[] = [];
        var currentImageWebURL="";
        if(this._imageserverRelativeURL.indexOf("/sites")>-1 &&this._currentWebUrl.indexOf(this._imageserverRelativeURL)>-1)
        {
            currentImageWebURL=this._currentWebUrl.substring(0,this._currentWebUrl.indexOf(this._imageserverRelativeURL));
        }
        else{
            currentImageWebURL=this._currentWebUrl;
        }
        return new Promise<ISnapShotImages[]>((resolve: (itemId: any) => void, reject: (error: any) => void): void => {
            this.readImages(listName, language)
                .then((carouselItems: ISnapShotImage[]): void => {
                    var i: number = 0;
                    for (i = 0; i < carouselItems.length; i++) {
                            const test: ISnapShotImage  ={ FileRef: currentImageWebURL + carouselItems[i].FileRef,Id:carouselItems[i].Id, Desc:carouselItems[i].Desc,DescES:carouselItems[i].DescES,DescPT:carouselItems[i].DescPT,Link:carouselItems[i].Link, LinkES:carouselItems[i].LinkES,LinkPT:carouselItems[i].LinkPT};
                            images.push(test);
                        }
                    
                    resolve(images);
                });
        });
    }

    public readImages(listName: string, language:string): Promise<ISnapShotImage[]> {
        //let date: Date;
        let newDate = new Date();
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();
        let separator="-";
        let todayDate= `${year}${separator}${month<10?`0${month}`:`${month}`}${separator}${date}`+'T07:00:00Z';
        return new Promise<ISnapShotImage[]>((resolve: (itemId: ISnapShotImage[]) => void, reject: (error: any) => void): void => {
            //this._spHttpClient.get(`${this._currentWebUrl}/_api/web/lists/getbytitle('${listName}')/items?$select=ID,Desc,Language,FileRef/FileRef&$filter=FSObjType eq 0 and Language eq '${language}' and EndDate ge datetime'${todayDate}' and StartDate le datetime'${todayDate}'&$top=4`,
            let selectFields='';
            if(language == 'EN')
            {
                selectFields='ID,Desc,Link,Language,FileRef/FileRef';
            }
            else if(language=='ES')
            {
                selectFields='ID,DescES,LinkES,Link,Desc,Language,FileRef/FileRef';
            }
            else if(language=='PT')
            {
                selectFields='ID,DescPT,LinkPT,Language,FileRef/FileRef';
            }
            this._spHttpClient.get(`${this._currentWebUrl}/_api/web/lists/getbytitle('${listName}')/items?$Select=${selectFields} &$filter=FSObjType eq 0 and isActive eq 1 and Language eq '${language}' and StartDate le datetime'${todayDate}' &$top=4`,
                SPHttpClient.configurations.v1,
                {
                    headers: {
                        'Accept': 'application/json;odata=nometadata',
                        'odata-version': ''
                    }
                })
                .then((response: SPHttpClientResponse): Promise<{ value: ISnapShotImage[] }> => {
                    return response.json();
                })
                .then((response: { value: ISnapShotImage[] }): void => {
                    resolve(response.value);
                }, (error: any): void => {
                    reject(error);
                });
        });
    }
}