export interface IDataService {
    getImages: (listName?: string, language?:string) => Promise<any>;
    //uploadImage:(listName?:string) => Promise<any>;
    GetFolderServerRelativeURL:(file?:any,fileName?:any,DocumentLibPath?:any, desc?:any, language?:any,descES?:any,descPT?:any)=>Promise<any>;
}  