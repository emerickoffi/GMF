git checkout dev
. ${NVM_DIR}/nvm.sh
npm config delete prefix
nvm install 10
nvm use 10
npm install -g gulp
npm install
npm rebuild node-sass
gulp trust-dev-cert
cp /home/vsonline/.gcb-serve-data/gcb-serve.cer .