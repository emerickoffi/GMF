/* eslint-disable @typescript-eslint/no-explicit-any */
import * as React from 'react';
import styles from './Snapshot.module.scss';
import type { ISnapshotProps } from './ISnapshotProps';
import { ISnapshotState } from './ISnapshotState';
import { IReturnedImages } from './interfaces';
import { Modal, IconButton, IIconProps, FontWeights, getTheme, mergeStyleSets, IButtonStyles, PrimaryButton, Checkbox, Spinner, SpinnerSize, Stack, Label } from '@fluentui/react';
import { TextField } from 'office-ui-fabric-react';
import { getSP } from '../../../services/DataService';
import { SPFI  } from '@pnp/sp';
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/files';
import '@pnp/sp/folders';
import '@pnp/sp/attachments';
import '@pnp/sp/fields';

export default class Snapshot extends React.Component<ISnapshotProps, ISnapshotState> {

  /* Let's initialize the SharePoint Framework instance */
  public _sp: SPFI = getSP(this.props.context);

  /* Let's create the list name variable */
  public listName: string = this.props.listId ? (this.props.listId.title ?? "") : "Snapshot";

  /* Let's create a method to get list data */  
  public getListData = async (language: string): Promise<IReturnedImages[]> => {
    /* Let's create a filter for language */
    const filter = `isActive eq 1 and Language eq '${language}'`;
    /* Let's grab the list data, filter by language, select the defined columns, and return the top 4 results! */
    const items = await this._sp.web.lists.getByTitle(this.listName).items.filter(filter).orderBy("StartDate", false).select("Id", "Title", "FileRef", "FileLeafRef", "Created", "Desc", "DescES", "DescPT", "Link", "LinkES", "LinkPT", "Language").top(4)();
    return items;
  }

  /* Let's create the constructor */
  constructor(props: ISnapshotProps) {
    super(props);

    /* Let's initialize the state */
    this.state = {
      items: [],
      submitPhoto: false,
      openImage: false,
      isModalOpen: false,
      modalImageSrc: "",
      modalImageAlt: "",
      modalUploadMessage: "",
      modalUploadMessageENDesc: "",
      modalUploadMessageESDesc: "",
      modalUploadMessagePTDesc: "",
      modalUploadFile: undefined,
      modalUploadFileName: "",
      modalUploadLanguageEN: "",
      modalUploadLanguageENDesc: "",
      modalUploadLanguageES: "",
      modalUploadLanguageESDesc: "",
      modalUploadLanguagePT: "",
      modalUploadLanguagePTDesc: "",
      pendingUpload: false
    };

    /* Let's bind the methods to the component */
    this.loadGallery = this.loadGallery.bind(this);
    this.openImage = this.openImage.bind(this);
    this.closeImage = this.closeImage.bind(this);
    this.showImageModal = this.showImageModal.bind(this);
    this.hideImageModal = this.hideImageModal.bind(this);
    this.showUploadModal = this.showUploadModal.bind(this);
    this.hideUploadModal = this.hideUploadModal.bind(this);
    this.submitImage = this.submitImage.bind(this);
    this.handleFileChange = this.handleFileChange.bind(this);
    this.getDescriptionLanguageEN = this.getDescriptionLanguageEN.bind(this);
    this.getDescriptionLanguageENDesc = this.getDescriptionLanguageENDesc.bind(this);
    this.getDescriptionLanguageES = this.getDescriptionLanguageES.bind(this);
    this.getDescriptionLanguageESDesc = this.getDescriptionLanguageESDesc.bind(this);
    this.getDescriptionLanguagePT = this.getDescriptionLanguagePT.bind(this);
    this.getDescriptionLanguagePTDesc = this.getDescriptionLanguagePTDesc.bind(this);
  }


  /* Let's create the loadGallery method */
  /* This method will fetch the list data and set it into the state */
  /* It will also log the data for debugging purposes */
  public async loadGallery():Promise<void>{
    console.log("loadGallery!");

    /* Let's create an async function that grabs list data via getListData() */
     const getListData = async (list: string): Promise<[]> => {
      const listData:[] = await this.getListData(this.props.language)
        .then(returnedItems => returnedItems)
        .catch((err) => {
          console.error("the following error(s) returned for " + list + ":", err);
          return err;
        });
      return listData;
    }

    /* Let's get the list name to pass */
    const listData = await getListData(this.listName);
    
    /* OK, let's set these into the state! */
    this.setState({ items: listData });

    /* Please do not remove this log as it is used for debugging purposes */
    console.log("listData is: ", listData);
  }

  /* Let's open the image in a modal */
  /* This method will set the image source and alt text into the state */
  /* It will also show the image modal */
  public async openImage( imageProps: { src: string, alt: string } ):Promise<void>{
    this.setState({ modalImageSrc: imageProps.src, modalImageAlt: imageProps.alt });
    this.showImageModal(); 
  }

  /* Let's close the image modal */
  /* This method will set the openImage state to false */
  /* It will also log the action for debugging purposes */
  public async closeImage():Promise<void>{
    console.log("closeImage!");
    this.setState({ openImage: false });
  } 

  /* I'm the method that shows the Image Modal */
  public showImageModal = (): void => {
    this.setState({ isModalOpen: true });
  }

    /* I'm the method that hides the Image Modal */
  public hideImageModal = (): void => {
    this.setState({ isModalOpen: false });
  }
  
  /* I'm the method that shows the Upload Modal */
  public showUploadModal = (): void => {
    this.setState({ submitPhoto: true });
  }
  
  /* I'm the method that hides the Upload Modal */
  public hideUploadModal = (): void => {
    this.setState({ submitPhoto: false });
  }
  
  /* I'm the method that handles the file change event */
  public handleFileChange = (event: React.ChangeEvent<HTMLInputElement>): void => {
    const file = event.target.files ? event.target.files[0] : undefined;
    if (file) {
      this.setState({ modalUploadFile: file, modalUploadFileName: file.name });
    } else {
      this.setState({ modalUploadFile: undefined });
      console.log("No file selected");
    }
  }

  /* I'm the method to set the language as English */
  public getDescriptionLanguageEN = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined, isChecked?: boolean | undefined): Promise<void> => {
    if (isChecked === true) {
      this.setState({ modalUploadLanguageEN: "EN", modalUploadMessage: "" });
    } else {
      this.setState({ modalUploadLanguageEN: "", modalUploadMessageENDesc: "" });
    }
  }

  /* I'm the method to set the English language description */
  public getDescriptionLanguageENDesc = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined): Promise<void> => {
    const value = (ev?.target as HTMLInputElement).value;
    this.setState({ modalUploadLanguageENDesc: value });
    if (value.length === 255) {
      this.setState({ modalUploadMessageENDesc: "Your description has reached the 255 character limit." });
    } else {
      this.setState({ modalUploadMessageENDesc: "" });
    }
  }

  /* I'm the method to set the language as Spanish */
  public getDescriptionLanguageES = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined, isChecked?: boolean | undefined): Promise<void> => {
    if (isChecked === true) {
      this.setState({ modalUploadLanguageES: "ES", modalUploadMessage: "" });
    } else {
      this.setState({ modalUploadLanguageES: "", modalUploadMessageESDesc: "" });
    }
  }

  /* I'm the method to set the Spanish language description */
  public getDescriptionLanguageESDesc = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined): Promise<void> => {
    const value = (ev?.target as HTMLInputElement).value;
    this.setState({ modalUploadLanguageESDesc: value });
    if (value.length === 255) {
      this.setState({ modalUploadMessageESDesc: "Tu descripción ha alcanzado el límite de 255 caracteres" });
    } else {
      this.setState({ modalUploadMessageESDesc: "" });
    }
  }

  /* I'm the method to set the language as Portuguese */
  public getDescriptionLanguagePT = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined, isChecked?: boolean | undefined): Promise<void> => {
    if (isChecked === true) {
      this.setState({ modalUploadLanguagePT: "PT", modalUploadMessage: "" });
    } else {
      this.setState({ modalUploadLanguagePT: "", modalUploadMessagePTDesc: ""});
    }
  }

  /* I'm the method to set the Portuguese language description */
  public getDescriptionLanguagePTDesc = async (ev?: React.FormEvent<HTMLInputElement | HTMLElement> | undefined): Promise<void> => {
    const value = (ev?.target as HTMLInputElement).value;
    this.setState({ modalUploadLanguagePTDesc: value });
    if (value.length === 255) {
      this.setState({ modalUploadMessagePTDesc: "Sua descrição atingiu o limite de 255 caracteres" });
    } else {
      this.setState({ modalUploadMessagePTDesc: "" });
    }
  }

  /* I check to see if the images are selected and if they are, add them to the Result array, and then return it! */
  public getLanguages = (lang1: string, lang2:string, lang3:string):string[] => {
    const result: string[] = [];
    if (lang1 !== "") {
      result.push(lang1);
    }
    if (lang2 !== "") {
      result.push(lang2);
    }
    if (lang3 !== "") {
      result.push(lang3);
    }
    return result;
  }

  /* I create the method to create a list item and attach a file */
  public async createListItemAndAttachFile(itemTitle: string, fileName: string, fileContent: Blob):Promise<void> {
    try {
      console.log("Starting file upload process...");
      console.log("List name:", this.listName);
      
      /* First, let's verify the list exists and check if it's a document library */
      const listInfo = await this._sp.web.lists.getByTitle(this.listName).select("Id", "Title", "BaseType", "BaseTemplate")();
      console.log("List found:", listInfo);
      
      /* Check if this is a document library (BaseType 1) */
      if (listInfo.BaseType === 1) {
        console.log("Detected document library - using file upload approach");
        await this.uploadToDocumentLibrary(itemTitle, fileName, fileContent);
      } else {
        console.log("Detected regular list - using list item approach");
        await this.uploadToRegularList(itemTitle, fileName, fileContent);
      }

    } catch (error) {
      console.error("Error creating list item and attaching file:", error);
      
      /* Provide more specific error messages */
      if (error.message.includes("Access denied")) {
        console.log("Access denied. Please ensure you have permission to add items to this list and that the web part has the necessary API permissions approved.");
      } else if (error.message.includes("does not exist")) {
        console.log(`The list "${this.listName}" does not exist. Please check the list name in the web part properties.`);
      } else if (error.message.includes("SPFileCollection.Add")) {
        console.log("This appears to be a document library. The upload method has been updated to handle this.");
      } else {
        console.log(`Error uploading file: ${error.message}`);
      }
    }
  }

      /* Method to handle uploads to document libraries */
  private async uploadToDocumentLibrary(itemTitle: string, fileName: string, fileContent: Blob): Promise<void> {
    try {
      console.log("Uploading to document library...");
      
      /* Get the selected languages */
      const selectedLanguages = this.getLanguages(this.state.modalUploadLanguageEN, this.state.modalUploadLanguageES, this.state.modalUploadLanguagePT);
      
      /* Upload the file to the document library */
      const fileAddResult = await this._sp.web.lists.getByTitle(this.listName).rootFolder.files.addUsingPath(fileName, fileContent, { Overwrite: true });
      console.log("File uploaded successfully:", fileAddResult);

      /* Get the list item associated with the uploaded file */
      const file = this._sp.web.getFileByServerRelativePath(fileAddResult.ServerRelativeUrl);
      const fileItem = await file.getItem();
      
      /* Update the file's metadata step by step to isolate any problematic fields */
      try {
        /* Start with just the Title */
        await fileItem.update({ Title: itemTitle });
        console.log("Title updated successfully");

        /* Add description fields one by one */
        if (this.state.modalUploadLanguageENDesc) {
          try {
            await fileItem.update({ Desc: this.state.modalUploadLanguageENDesc });
            console.log("English description updated successfully");
          } catch (descError) {
            console.error("Error updating English description:", descError);
          }
        }

        if (this.state.modalUploadLanguageESDesc) {
          try {
            await fileItem.update({ DescES: this.state.modalUploadLanguageESDesc });
            console.log("Spanish description updated successfully");
          } catch (descError) {
            console.error("Error updating Spanish description:", descError);
          }
        }

        if (this.state.modalUploadLanguagePTDesc) {
          try {
            await fileItem.update({ DescPT: this.state.modalUploadLanguagePTDesc });
            console.log("Portuguese description updated successfully");
          } catch (descError) {
            console.error("Error updating Portuguese description:", descError);
          }
        }

        /* Handle Language field carefully */
        if (selectedLanguages.length > 0) {
          try {
            /* Try different formats for the Language field */
            console.log("Attempting to update Language field with:", selectedLanguages);
            /* Multiple selections - try as array */
            await fileItem.update({ Language: selectedLanguages });
            console.log("Language updated successfully as array");
          } catch (langError) {
            console.error("Error updating Language field:", langError);
          }
        }

        /* Let's hide the modal! */
        this.hideUploadModal();
        /* Let's refresh the gallery  */
        await this.loadGallery();
        /* Let's reset the form state, just in case they want to submit another image */
        this.setState({ 
          modalUploadFile: undefined, 
          modalUploadFileName: "",
          modalUploadLanguageEN: "",
          modalUploadLanguageENDesc: "",
          modalUploadLanguageES: "",
          modalUploadLanguageESDesc: "",
          modalUploadLanguagePT: "",
          modalUploadLanguagePTDesc: "",
        });


      } catch (updateError) {
        console.error("Error during metadata update:", updateError);
        throw updateError;
      }

    } catch (error) {
      console.error("Error uploading to document library:", error);
      throw error;
    }
  }

  /* Method to handle uploads to regular lists */
  private async uploadToRegularList(itemTitle: string, fileName: string, fileContent: Blob): Promise<void> {
    try {
      console.log("Uploading to regular list...");
      
      /* Inspect the list fields to understand data types */
      await this.inspectListFields();
      
      /* Get the selected languages */
      const selectedLanguages = this.getLanguages(this.state.modalUploadLanguageEN, this.state.modalUploadLanguageES, this.state.modalUploadLanguagePT);
      
      /* Create the list item first */
      const itemAddResult = await this._sp.web.lists.getByTitle(this.listName).items.add({
        Title: itemTitle
      });
      console.log("Basic item created successfully:", itemAddResult);
      
      /* Now try to update with additional fields */
      const updateData: any = {};
      
      if (this.state.modalUploadLanguageENDesc) {
        updateData.Desc = this.state.modalUploadLanguageENDesc;
      }
      if (this.state.modalUploadLanguageESDesc) {
        updateData.DescES = this.state.modalUploadLanguageESDesc;
      }
      if (this.state.modalUploadLanguagePTDesc) {
        updateData.DescPT = this.state.modalUploadLanguagePTDesc;
      }
      
      if (selectedLanguages.length > 0) {
        updateData.Language = selectedLanguages;
      }
      
      try {
        updateData.isActive = true; // Use boolean true instead of 1
      } catch {
        console.warn("isActive field might not exist, continuing without it");
      }
      
      /* Update the item with additional fields */
      if (Object.keys(updateData).length > 0) {
        console.log("Updating item with additional data:", updateData);
        await this._sp.web.lists.getByTitle(this.listName).items.getById(itemAddResult.data.Id).update(updateData);
        console.log("Item updated successfully");
      }

      /* Try to attach the file to the list item */
      try {
        await this._sp.web.lists.getByTitle(this.listName).items.getById(itemAddResult.data.Id).attachmentFiles.add(fileName, fileContent);
        console.log("File attached successfully");
      } catch (attachError) {
        console.error("Error attaching file, but item was created:", attachError);
        alert("Item created but file attachment failed. Please check if attachments are enabled on this list.");
      }

    } catch (error) {
      console.error("Error uploading to regular list:", error);
      throw error;
    }
  }

  /* I call the CreateListItemAndAttachFile method! */
  public submitImage = async (): Promise<void> => {
    if (this.state.modalUploadFile && (this.state.modalUploadLanguageEN.length > 0 || this.state.modalUploadLanguageES.length > 0 || this.state.modalUploadLanguagePT.length > 0)) {
      this.setState({ pendingUpload: true });
      await this.createListItemAndAttachFile(this.state.modalUploadFileName, this.state.modalUploadFileName, this.state.modalUploadFile);
    } else {
      this.setState({ modalUploadMessage: "Please select a file and at least one language." });
    }
  }

  public async componentDidMount(): Promise<void> {
    /* Let's call loadGallery to load the images! */
    await this.loadGallery();
  }

  /* Helper method to inspect list fields for debugging */
  public async inspectListFields(): Promise<void> {
    try {
      const list = this._sp.web.lists.getByTitle(this.listName);
      const fields = await list.fields.select("Title", "TypeAsString", "FieldTypeKind", "Choices")();
      console.log("List fields information:", fields);
      
      /* Look specifically for our fields */
      const relevantFields = fields.filter((field: any) => 
        ['Language', 'Desc', 'DescES', 'DescPT', 'isActive'].includes(field.Title)
      );
      console.log("Relevant fields for upload:", relevantFields);
    } catch (error) {
      console.error("Error inspecting list fields:", error);
    }
  }

  public render(): React.ReactElement<ISnapshotProps> {

    /* Let's define some style configurations for the modals! */
    const cancelIcon: IIconProps = { iconName: 'Cancel' };
    const theme = getTheme();
    const contentStyles = mergeStyleSets({
      container: {
        display: 'flex',
        flexFlow: 'column nowrap',
        alignItems: 'stretch',
        borderTop: `4px solid ${theme.palette.themePrimary}`,
        minWidth: '700px',
      },
      header: [
        theme.fonts.large,
        {
          flex: '1 1 auto',
          borderTop: `4px solid ${theme.palette.themePrimary}`,
          color: theme.palette.neutralPrimary,
          display: 'flex',
          alignItems: 'center',
          fontWeight: FontWeights.semibold,
          padding: '12px 12px 14px 24px',
        },
      ],
      heading: {
        color: theme.palette.neutralPrimary,
        fontWeight: FontWeights.semibold,
        fontSize: 'inherit',
        margin: '0',
      },
      body: {
        flex: '4 4 auto',
        padding: '0 24px 24px 24px',
        overflowY: 'hidden',
        selectors: {
          p: { margin: '14px 0' },
          'p:first-child': { marginTop: 0 },
          'p:last-child': { marginBottom: 0 },
        },
      },
      upload__fieldset: {
        flex: "1 1 auto",
        border: 'none',
      },
      upload__legend: {
        color: theme.palette.themePrimary,
        fontWeight: FontWeights.semibold,
        fontSize: '1.36em',
        borderBottom: `2px solid ${theme.palette.themePrimary}`,
        width: '100%'
      },
      h2: {
        color: theme.palette.themePrimary,
        fontWeight: FontWeights.semibold,
        fontSize: '1.18em',
        margin: '0',
        padding: '0',
        width: '100%'
      },
      label: {
        display: 'block',
      },
      fieldset__row: {
        padding: '5px 0',
      },
      button__right: {
        display: 'flex',
        flexDirection: 'row-reverse',
        justifySelf: 'flex-end',
      },
      error: {
        backgroundColor: theme.palette.redDark,
        color: theme.palette.white,
        padding: '10px',
        borderRadius: '4px',
        marginTop: '10px',
      },
      warning: {
        backgroundColor: theme.palette.yellow,
        color: theme.palette.black,
        padding: '10px',
        borderRadius: '4px',
        marginTop: '5px !important',
      },
      submit: {
        marginRight: '1em',
      },
      uploadingLabel: {
        paddingLeft: '.5em'
      }
    });
    const iconButtonStyles: Partial<IButtonStyles> = {
      root: {
        color: theme.palette.neutralPrimary,
        marginLeft: 'auto',
        marginTop: '4px',
        marginRight: '2px',
      },
      rootHovered: {
        color: theme.palette.neutralDark,
      }
    };

    return (
      <section className={`${styles.snapshot}`}>
        {/* Snapshot Menu */}
        <div className="snapshot-menu">
          <div className="snapshot-menu__item snapshot-menu__item--first">
            <h1 className="snapshot-menu__h1">{ this.props.description }</h1>
          </div>
          <div className="snapshot-menu__item">
            <button className="snapshot-menu__button--submit-a-photo" onClick={ this.showUploadModal }><span>{ this.props.language === "ES" ? "Enviar una foto" : this.props.language === "PT" ? "Envie uma foto" : "+ Submit a Photo" }</span></button>
          </div>
          <div className="snapshot-menu__item snapshot-menu__item--last">
            <a className="snapshot-menu__a--view-all" href={this.props.viewAllUrl}>{ this.props.language === "ES" ? "Ver todo" : this.props.language === "PT" ? "Ver tudo" : "See All" }</a>
          </div>
        </div>
        {/* Snapshot Gallery */}
        <div className="snapshot-gallery">
          { 
            this.state.items.map((item: IReturnedImages) => {
              return (
                <div className="snapshot-gallery__item" key={item.Id}>
                  {/* Force aspect ratio 8:3 via CSS */}
                  <div className="snapshot-gallery__image-container">
                    <img
                      alt={ this.props.language === "ES" ? item.DescES : this.props.language === "PT" ? item.DescPT : item.Desc }
                      className="snapshot-gallery__image"
                      src={ item.FileRef }
                      width="100%"
                      onClick={ () => this.openImage({ src: item.FileRef, alt: this.props.language === "ES" ? item.DescES : this.props.language === "PT" ? item.DescPT : item.Desc }) }
                    />
                  </div>
                  <p className="snapshot-gallery__description">{ this.props.language === "ES" ? item.DescES : this.props.language === "PT" ? item.DescPT : item.Desc }</p>
                </div>
              );
            }) 
          }
        </div>
        { /* View Image Modal */ }
        <Modal
          titleAriaId='View Image'
          onDismiss={ this.hideImageModal }
          isOpen={ this.state.isModalOpen }
        >
          <div className={contentStyles.container}>
            <IconButton
              iconProps={ cancelIcon }
              ariaLabel="Close popup modal"
              styles={ iconButtonStyles }
              onClick={this.hideImageModal}
            />
            <div className={contentStyles.body}>
              <img alt={ this.state.modalImageAlt ? this.state.modalImageAlt : '' } src={ this.state.modalImageSrc } width="800" />
              <p>{ this.state.modalImageAlt ? this.state.modalImageAlt : '' }</p>
              <PrimaryButton className={contentStyles.button__right} text="Close" onClick={ this.hideImageModal } />
            </div>
          </div>
        </Modal>

        { /* Upload Image Modal */ }
        <Modal
          titleAriaId={ this.props.language === "ES" ? "Enviar uma foto" : this.props.language === "PT" ? "Envie uma foto" : "Submit a Photo" }
          onDismiss={ this.hideUploadModal }
          isOpen={ this.state.submitPhoto }
        >
          <div className={contentStyles.container}>
            <IconButton
              iconProps={ cancelIcon }
              ariaLabel="Close popup modal"
              styles={ iconButtonStyles }
              onClick={this.hideUploadModal}
            />
            <div className={contentStyles.body}>
              <fieldset className={contentStyles.upload__fieldset}>
                <legend className={contentStyles.upload__legend}>{ this.props.language === "ES" ? "Enviar una foto" : this.props.language === "PT" ? "Envie uma foto" : "Submit a Photo" }</legend>
                <div className={ contentStyles.fieldset__row }>
                  <h2 className={ contentStyles.h2 }>Select your image</h2>
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <input type="file" accept="image/*" onChange={ this.handleFileChange } />
                  <label className={contentStyles.label}>Upload your image here. Please ensure it is in a <em>supported image format</em> (e.g., JPG, PNG).</label>
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <h2 className={ contentStyles.h2 }>Set your language(s)</h2>
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <Checkbox label="English" id="languageEN" name="languageEN" onChange={ this.getDescriptionLanguageEN } />
                  { this.state.modalUploadLanguageEN &&
                    <div className={ contentStyles.fieldset__row }>
                      <TextField 
                        label="Describe your image. Include information like team/department name(s) and locations"
                        maxLength={255}
                        multiline={this.state.modalUploadLanguageENDesc.length > 50}
                        placeholder="Description in English (limited to 255 characters)" 
                        resizable={false}
                        rows={this.state.modalUploadLanguageENDesc.length > 50 ? 3 : 1}
                        onChange={ this.getDescriptionLanguageENDesc }
                      />
                    </div>
                  }
                  { this.state.modalUploadMessageENDesc && <p className={contentStyles.warning}>{ this.state.modalUploadMessageENDesc }</p> }
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <Checkbox label="Español" id="languageES" name="languageES" onChange={ this.getDescriptionLanguageES } />
                  { this.state.modalUploadLanguageES &&
                    <div className={ contentStyles.fieldset__row }>
                      <TextField 
                        label="Describe tu imagen. Incluye información como el nombre del equipo o departamento y sus ubicaciones"
                        maxLength={255} 
                        multiline={this.state.modalUploadLanguageESDesc.length > 50}
                        placeholder="Descripción en Español (límite de 255 caracteres)" 
                        resizable={false}
                        rows={this.state.modalUploadLanguageESDesc.length > 50 ? 3 : 1}
                        onChange={ this.getDescriptionLanguageESDesc }
                      />
                    </div>
                  }
                  { this.state.modalUploadMessageESDesc && <p className={contentStyles.warning}>{ this.state.modalUploadMessageESDesc }</p> }
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <Checkbox label="Português" id="languagePT" name="languagePT" onChange={ this.getDescriptionLanguagePT } />
                  { this.state.modalUploadLanguagePT &&
                    <div className={ contentStyles.fieldset__row }>
                      <TextField
                        label="Descreva sua imagem. Inclua informações como o nome da equipe/departamento e as localizações"
                        maxLength={255} 
                        multiline={this.state.modalUploadLanguagePTDesc.length > 50}
                        placeholder="Descrição em Português (limite de 255 caracteres)" 
                        resizable={false}
                        rows={this.state.modalUploadLanguagePTDesc.length > 50 ? 3 : 1}
                        onChange={ this.getDescriptionLanguagePTDesc }
                      />
                    </div>
                  }
                  { this.state.modalUploadMessagePTDesc && <p className={contentStyles.warning}>{ this.state.modalUploadMessagePTDesc }</p> }
                </div>
                <div className={ contentStyles.fieldset__row }>
                  <Stack horizontal={true} verticalAlign={"center"}>
                    <PrimaryButton className={ contentStyles.submit } text="Upload" onClick={ this.submitImage } disabled={ this.state.modalUploadFile ? false : true } />
                    {
                      this.state.pendingUpload && (
                        <>
                          <Spinner size={SpinnerSize.medium} />
                          <Label className={ contentStyles.uploadingLabel }>Uploading...</Label>
                        </>
                      )
                    }
                  </Stack>
                  { this.state.modalUploadMessage &&
                    <div className={ contentStyles.error }>
                      { this.state.modalUploadMessage && <p>{ this.state.modalUploadMessage }</p> }
                    </div>
                  }
                </div>
              </fieldset>
            </div>
          </div>
        </Modal>
      </section>
    );
  }
}
