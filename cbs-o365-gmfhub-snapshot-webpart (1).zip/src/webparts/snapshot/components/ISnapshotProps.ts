import { WebPartContext } from "@microsoft/sp-webpart-base";
import { IPropertyFieldList } from "@pnp/spfx-property-controls";
export interface ISnapshotProps {
  description: string;
  context: WebPartContext;
  listId: IPropertyFieldList;
  listName: string;
  viewAllUrl: string;
  language: string;
}
