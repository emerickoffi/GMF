export interface IReturnedImages {
    Id: number;
    Title: string;
    FileRef: string;
    FileLeafRef: string;
    Created: Date;
    Desc: string;
    DescES: string;
    DescPT: string;
    Link: string;
    LinkES: string;
    LinkPT: string;
    Language: string[];
}