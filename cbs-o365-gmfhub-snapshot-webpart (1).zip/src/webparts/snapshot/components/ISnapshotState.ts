export interface ISnapshotState {
    items: [];
    submitPhoto: boolean;
    openImage: boolean;
    isModalOpen: boolean;
    modalImageSrc: string;
    modalImageAlt: string;
    modalUploadMessage: string;
    modalUploadMessageENDesc: string;
    modalUploadMessageESDesc: string;
    modalUploadMessagePTDesc: string;
    modalUploadFile: File | undefined;
    modalUploadFileName: string;
    modalUploadLanguageEN: string;
    modalUploadLanguageENDesc: string
    modalUploadLanguageES: string;
    modalUploadLanguageESDesc: string;
    modalUploadLanguagePT: string;
    modalUploadLanguagePTDesc: string;
    pendingUpload: boolean;
}