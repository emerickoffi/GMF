import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  type IPropertyPaneConfiguration,
  PropertyPaneDropdown,
  PropertyPaneTextField
 } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import {
  PropertyFieldListPicker,
  PropertyFieldListPickerOrderBy,
  IPropertyFieldList
} from '@pnp/spfx-property-controls/lib/PropertyFieldListPicker';

import Snapshot from './components/Snapshot';
import { ISnapshotProps } from './components/ISnapshotProps';

export interface ISnapshotWebPartProps {
  description: string;
  context: string;
  listId: IPropertyFieldList;
  listName: string;
  viewAllUrl: string;
  language: string;
}

export default class SnapshotWebPart extends BaseClientSideWebPart<ISnapshotWebPartProps> {

  public render(): void {
    const element: React.ReactElement<ISnapshotProps> = React.createElement(
      Snapshot,
      {
        description: this.properties.description,
        context: this.context,
        listId: this.properties.listId,
        listName: this.properties.listName,
        viewAllUrl: this.properties.viewAllUrl,
        language: this.properties.language
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          groups: [
            {
              groupFields: [
                // description field, list name, language, view all URL
                PropertyFieldListPicker('listId', {
									label: 'Select list',
									selectedList: this.properties.listId,
									includeHidden: false,
									orderBy: PropertyFieldListPickerOrderBy.Title,
									disabled: false,
									onPropertyChange: this.onPropertyPaneFieldChanged.bind(this),
									properties: this.properties,
									context: this.context,
									onGetErrorMessage: undefined,
									deferredValidationTime: 0,
									includeListTitleAndUrl: true,
									key: 'listPickerFieldId'
								}),
                PropertyPaneTextField('description', {
                  label: 'Description',
                  value: this.properties.description,
                  multiline: false,
                  resizable: false
                }),
                PropertyPaneTextField('viewAllUrl', {
                  label: 'View All URL',
                  value: this.properties.viewAllUrl,
                  multiline: false,
                  resizable: false
                }),
								PropertyPaneDropdown('language', {
									label: 'Language',
									options: [
										// { key:"", text:"Use Browser"},
										{ key: 'EN', text: 'EN' },
										{ key: 'ES', text: 'ES' },
										{ key: 'PT', text: 'PT' }
									]
								}),
              ]
            }
          ]
        }
      ]
    };
  }
}
