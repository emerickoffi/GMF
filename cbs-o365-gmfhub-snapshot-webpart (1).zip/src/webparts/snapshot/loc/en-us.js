define([], function() {
  return {
  }
});