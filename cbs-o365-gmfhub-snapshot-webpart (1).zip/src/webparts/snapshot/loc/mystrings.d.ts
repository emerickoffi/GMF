declare interface ISnapshotWebPartStrings {
}

declare module 'SnapshotWebPartStrings' {
  const strings: ISnapshotWebPartStrings;
  export = strings;
}
