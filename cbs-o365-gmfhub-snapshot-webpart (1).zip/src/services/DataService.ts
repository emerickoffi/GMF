import { WebPartContext } from "@microsoft/sp-webpart-base";
import { spfi, SPFI, SPFx } from "@pnp/sp";
import { LogLevel, PnPLogging } from "@pnp/logging";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/batching";

// eslint-disable-next-line @rushstack/no-new-null
let _sp: SPFI | null = null;

export const getSP = (context?: WebPartContext): SPFI => {
  // eslint-disable-next-line eqeqeq
  if (context != null) {
    //You must add the @pnp/logging package to include the PnPLogging behavior it is no longer a peer dependency
    // The LogLevel set's at what level a message will be written to the console
    _sp = spfi().using(SPFx(context)).using(PnPLogging(LogLevel.Warning));
  }
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  return _sp!;
};

/* Hey, what if I want to navigate in a page with the back button?  How do I do that without a blank webpart loading? */
export const disposeSP = (): void => {
  _sp = null;
}